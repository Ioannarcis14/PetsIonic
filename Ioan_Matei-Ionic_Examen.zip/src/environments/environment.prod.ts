export const environment = {
  firebase: {
    apiKey: "AIzaSyAncxpvwufBmhqPFxNDctRW76u7Td6wSuI",
    authDomain: "petstinderfb.firebaseapp.com",
    projectId: "petstinderfb",
    storageBucket: "petstinderfb.appspot.com",
    messagingSenderId: "353973094189",
    appId: "1:353973094189:web:e8ba1e76748ca47ca2b5a4"
  },
  production: true
};
