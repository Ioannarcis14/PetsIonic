export interface User {
    name: string;
    email: string;
    uuid: string;
    profile_pic: string;
}
