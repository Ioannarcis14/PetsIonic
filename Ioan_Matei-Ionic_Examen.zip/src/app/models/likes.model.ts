export interface Likes {
    id_pet: string;
    id_user: string;
}
