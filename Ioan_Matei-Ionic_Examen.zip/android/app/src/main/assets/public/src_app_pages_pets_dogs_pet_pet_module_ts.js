"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_pets_dogs_pet_pet_module_ts"],{

/***/ 7756:
/*!***********************************************************!*\
  !*** ./src/app/pages/pets/dogs/pet/pet-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PetPageRoutingModule": () => (/* binding */ PetPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _pet_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pet.page */ 7636);




const routes = [
    {
        path: '',
        component: _pet_page__WEBPACK_IMPORTED_MODULE_0__.PetPage
    }
];
let PetPageRoutingModule = class PetPageRoutingModule {
};
PetPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PetPageRoutingModule);



/***/ }),

/***/ 2084:
/*!***************************************************!*\
  !*** ./src/app/pages/pets/dogs/pet/pet.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PetPageModule": () => (/* binding */ PetPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _pet_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pet-routing.module */ 7756);
/* harmony import */ var _pet_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pet.page */ 7636);







let PetPageModule = class PetPageModule {
};
PetPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _pet_routing_module__WEBPACK_IMPORTED_MODULE_0__.PetPageRoutingModule
        ],
        declarations: [_pet_page__WEBPACK_IMPORTED_MODULE_1__.PetPage]
    })
], PetPageModule);



/***/ }),

/***/ 7636:
/*!*************************************************!*\
  !*** ./src/app/pages/pets/dogs/pet/pet.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PetPage": () => (/* binding */ PetPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _home_ioan_Documents_DAW2_Ionic_PetsIonic_node_modules_ngtools_webpack_src_loaders_direct_resource_js_pet_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./pet.page.html */ 7159);
/* harmony import */ var _pet_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pet.page.scss */ 1031);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var src_app_services_rescue_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/rescue-service.service */ 9561);






let PetPage = class PetPage {
    constructor(route, cService, router) {
        this.route = route;
        this.cService = cService;
        this.router = router;
    }
    ngOnInit() {
        //primer obtenim la id
        this.animal_id = this.route.snapshot.queryParams.id;
        //despres diferenciem entre si es un gat o un gos
        if (this.router.url.includes("dogs"))
            this.animal = this.getDogs[this.animal_id];
        else
            this.animal = this.getCats[this.animal_id];
        //agafem totes les propietats i tots els atributs
        this.biografia = this.animal.biography;
        this.vacunes = this.animal.vaccines;
        if (this.vacunes == "")
            this.vacunes = "NO";
        this.malalties = this.animal.diseases;
        if (this.malalties == "")
            this.malalties = "NO";
        this.edat = this.calcularEdat(new Date(this.animal.birthdate));
        this.dataNaixement = this.convertDate(this.animal.birthdate);
    }
    //GETS
    get getDogs() {
        return this.cService.getDogs;
    }
    get getCats() {
        return this.cService.getCats;
    }
    //DATA FORMAT CATALÀ
    convertDate(inputFormat) {
        var d = new Date(inputFormat);
        return [this.pad(d.getDate()), this.pad(d.getMonth() + 1), d.getFullYear()].join('/');
    }
    pad(s) { return (s < 10) ? '0' + s : s; }
    //CALCULAR EDAT A PARTIR D'UNA DATA
    calcularEdat(fecha) {
        var avui = new Date();
        var aniversari = new Date(fecha);
        var edat = avui.getFullYear() - aniversari.getFullYear();
        var m = avui.getMonth() - aniversari.getMonth();
        if (m < 0 || (m === 0 && avui.getDate() < aniversari.getDate()))
            edat--;
        return edat;
    }
};
PetPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute },
    { type: src_app_services_rescue_service_service__WEBPACK_IMPORTED_MODULE_2__.RescueServiceService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
PetPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-pet',
        template: _home_ioan_Documents_DAW2_Ionic_PetsIonic_node_modules_ngtools_webpack_src_loaders_direct_resource_js_pet_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_pet_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], PetPage);



/***/ }),

/***/ 7159:
/*!******************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/pets/dogs/pet/pet.page.html ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Pet</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n <ion-content>\n  <ion-slides pager=\"true\" [options]=\"slideOpts\">\n    <ion-slide *ngFor=\"let dog of getDogs;let i=index\">\n        <ion-card>\n          <ion-header>\n            <img src=\"{{animal.carousel_imgs[i]}}\" alt=\"First slide\">\n          </ion-header>\n          <ion-card-content>\n            {{biografia}}\n            <ion-list>\n              <ion-item>\n                <ion-label>\n                  <span class=\"listTitle\">Sexe</span>\n                  <p>{{animal.sex}}</p>\n                </ion-label>\n              </ion-item>\n              <ion-item>\n                <ion-label>\n                  <span class=\"listTitle\">Naixement</span>\n                  <p>{{dataNaixement}}</p>\n                </ion-label>\n              </ion-item>\n              <ion-item>\n                <ion-label>\n                  <span class=\"listTitle\">Edat</span>\n                  <p>{{edat}} anys</p>\n                </ion-label>\n              </ion-item>\n              <ion-item>\n                <ion-label>\n                  <span class=\"listTitle\">Xip</span>\n                  <p>{{animal.chip}}</p>\n                </ion-label>\n              </ion-item>\n              <ion-item>\n                <ion-label>\n                  <span class=\"listTitle\">Malalties</span>\n                  <p>{{malalties}}</p>\n                </ion-label>\n              </ion-item>\n              <ion-item>\n                <ion-label>\n                  <span class=\"listTitle\">Vacunes</span>\n                  <p>{{vacunes}}</p>\n                </ion-label>\n              </ion-item>\n              <ion-item>\n                <ion-label class=\"observations\">\n                  <span class=\"listTitle\">Observacions</span>\n                  <p>{{animal.observations}}</p>\n                </ion-label>\n              </ion-item>\n            </ion-list>\n          </ion-card-content>\n      </ion-card>\n    </ion-slide>\n  </ion-slides>\n</ion-content>\n\n\n");

/***/ }),

/***/ 1031:
/*!***************************************************!*\
  !*** ./src/app/pages/pets/dogs/pet/pet.page.scss ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "ion-slide ion-card {\n  width: 75%;\n}\nion-slide ion-card > ion-header {\n  object-fit: cover;\n  max-width: 100%;\n}\nion-slide ion-card > ion-header img {\n  object-fit: cover;\n  width: 100%;\n  height: 350px;\n}\nion-slide ion-card > ion-header::after {\n  display: none;\n}\nion-slide ion-list ion-label {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\nion-slide ion-list ion-label.observations {\n  flex-direction: column;\n  align-items: flex-start;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBldC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSxVQUFBO0FBQVI7QUFHSTtFQUNJLGlCQUFBO0VBQ0EsZUFBQTtBQURSO0FBR1E7RUFDSSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0FBRFo7QUFLSTtFQUNJLGFBQUE7QUFIUjtBQVFRO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUFOWjtBQVNRO0VBQ0ksc0JBQUE7RUFDQSx1QkFBQTtBQVBaIiwiZmlsZSI6InBldC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tc2xpZGUge1xuICAgIGlvbi1jYXJkIHtcbiAgICAgICAgd2lkdGg6IDc1JTtcbiAgICB9XG5cbiAgICBpb24tY2FyZCA+IGlvbi1oZWFkZXIge1xuICAgICAgICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgICAgICAgbWF4LXdpZHRoOiAxMDAlO1xuXG4gICAgICAgIGltZyB7XG4gICAgICAgICAgICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgaGVpZ2h0OiAzNTBweDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGlvbi1jYXJkID4gaW9uLWhlYWRlcjo6YWZ0ZXIge1xuICAgICAgICBkaXNwbGF5OiBub25lO1xuICAgIH1cbiAgICBcblxuICAgIGlvbi1saXN0IHtcbiAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICB9XG5cbiAgICAgICAgaW9uLWxhYmVsLm9ic2VydmF0aW9ucyB7XG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gICAgICAgIH1cbiAgICB9XG59Il19 */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_pets_dogs_pet_pet_module_ts.js.map