"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_pets_pets_module_ts"],{

/***/ 5848:
/*!***************************************************!*\
  !*** ./src/app/pages/pets/pets-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PetsPageRoutingModule": () => (/* binding */ PetsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _pets_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pets.page */ 3686);




const routes = [
    {
        path: '',
        component: _pets_page__WEBPACK_IMPORTED_MODULE_0__.PetsPage,
        children: [
            {
                path: 'cats',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_pets_cats_cats_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./cats/cats.module */ 8539)).then(m => m.CatsPageModule)
            },
            {
                path: 'dogs',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_pets_dogs_dogs_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./dogs/dogs.module */ 3488)).then(m => m.DogsPageModule)
            }
        ]
    }
];
let PetsPageRoutingModule = class PetsPageRoutingModule {
};
PetsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PetsPageRoutingModule);



/***/ }),

/***/ 2386:
/*!*******************************************!*\
  !*** ./src/app/pages/pets/pets.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PetsPageModule": () => (/* binding */ PetsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _pets_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pets-routing.module */ 5848);
/* harmony import */ var _pets_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pets.page */ 3686);







let PetsPageModule = class PetsPageModule {
};
PetsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _pets_routing_module__WEBPACK_IMPORTED_MODULE_0__.PetsPageRoutingModule
        ],
        declarations: [_pets_page__WEBPACK_IMPORTED_MODULE_1__.PetsPage]
    })
], PetsPageModule);



/***/ }),

/***/ 3686:
/*!*****************************************!*\
  !*** ./src/app/pages/pets/pets.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PetsPage": () => (/* binding */ PetsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _home_ioan_Documents_DAW2_Ionic_PetsIonic_node_modules_ngtools_webpack_src_loaders_direct_resource_js_pets_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./pets.page.html */ 5231);
/* harmony import */ var _pets_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pets.page.scss */ 3777);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);




let PetsPage = class PetsPage {
    constructor() { }
    ngOnInit() {
    }
};
PetsPage.ctorParameters = () => [];
PetsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-pets',
        template: _home_ioan_Documents_DAW2_Ionic_PetsIonic_node_modules_ngtools_webpack_src_loaders_direct_resource_js_pets_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_pets_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], PetsPage);



/***/ }),

/***/ 5231:
/*!**********************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/pets/pets.page.html ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-tabs>\n  <ion-tab-bar slot=\"bottom\" color=\"primary\">\n    <ion-tab-button tab=\"cats\">\n      <ion-label>Gats</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"dogs\">\n      <ion-label>Gossos</ion-label>\n    </ion-tab-button>\n  </ion-tab-bar>\n</ion-tabs>\n");

/***/ }),

/***/ 3777:
/*!*******************************************!*\
  !*** ./src/app/pages/pets/pets.page.scss ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwZXRzLnBhZ2Uuc2NzcyJ9 */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_pets_pets_module_ts.js.map