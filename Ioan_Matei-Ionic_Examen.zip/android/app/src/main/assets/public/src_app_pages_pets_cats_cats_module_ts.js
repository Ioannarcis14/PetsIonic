"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_pets_cats_cats_module_ts"],{

/***/ 2631:
/*!****************************************!*\
  !*** ./src/app/models/rescued-pets.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RescuedPets": () => (/* binding */ RescuedPets)
/* harmony export */ });
class RescuedPets {
    constructor() {
        this._pets = [];
    }
    get getPet() {
        return this._pets;
    }
    set setPet(pets) {
        this._pets = pets;
    }
}


/***/ }),

/***/ 9041:
/*!********************************************************!*\
  !*** ./src/app/pages/pets/cats/cats-routing.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CatsPageRoutingModule": () => (/* binding */ CatsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _cats_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cats.page */ 7654);




const routes = [
    {
        path: '',
        component: _cats_page__WEBPACK_IMPORTED_MODULE_0__.CatsPage
    },
    {
        path: 'pet',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_pets_cats_pet_pet_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pet/pet.module */ 65)).then(m => m.PetPageModule)
    }
];
let CatsPageRoutingModule = class CatsPageRoutingModule {
};
CatsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CatsPageRoutingModule);



/***/ }),

/***/ 8539:
/*!************************************************!*\
  !*** ./src/app/pages/pets/cats/cats.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CatsPageModule": () => (/* binding */ CatsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _cats_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cats-routing.module */ 9041);
/* harmony import */ var _cats_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cats.page */ 7654);







let CatsPageModule = class CatsPageModule {
};
CatsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _cats_routing_module__WEBPACK_IMPORTED_MODULE_0__.CatsPageRoutingModule
        ],
        declarations: [_cats_page__WEBPACK_IMPORTED_MODULE_1__.CatsPage]
    })
], CatsPageModule);



/***/ }),

/***/ 7654:
/*!**********************************************!*\
  !*** ./src/app/pages/pets/cats/cats.page.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CatsPage": () => (/* binding */ CatsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _home_ioan_Documents_DAW2_Ionic_PetsIonic_node_modules_ngtools_webpack_src_loaders_direct_resource_js_cats_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./cats.page.html */ 5698);
/* harmony import */ var _cats_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cats.page.scss */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var src_app_services_rescue_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/rescue-service.service */ 9561);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 6636);
/* harmony import */ var src_app_services_likes_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/likes.service */ 449);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);








let CatsPage = class CatsPage {
    constructor(cService, authServ, likeServ, toastController) {
        this.cService = cService;
        this.authServ = authServ;
        this.likeServ = likeServ;
        this.toastController = toastController;
        this.isSessionStarted();
    }
    ngOnInit() {
        this.likeServ.buttonLike();
        this.likeServ.getLikes();
        console.log(this.likeServ.buttonLike());
    }
    // Per al ngIf si s'ha iniciat sessió
    isSessionStarted() {
        return this.authServ.isSessionStarted();
    }
    get getCats() {
        return this.cService.getCats;
    }
    /*
    *  Comprovació per al ngIf ##
    *  comprova el parametre (bucle ngFor) amb l'id del pet
    */
    islike(id_like) {
        for (let i = 0; i < this.likeServ.getLikes().length; i++) {
            if (id_like == this.likeServ.getLikes()[i].id_pet) {
                return true;
            }
        }
        return false;
    }
    // El service s'encarrega de fer Like/Dislike
    ferLike(posId) {
        this.likeServ.likedPet(posId);
        this.likeServ.buttonLike();
        this.likeServ.getLikes();
        this.likeToast();
    }
    ferDislike(posId) {
        this.likeServ.deletelike(posId);
        this.dislikeToast();
    }
    likeToast() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: 'Has afegit aquesta Mascota a favorits',
                duration: 2000,
                color: 'secondary'
            });
            toast.present();
        });
    }
    dislikeToast() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: 'Has eliminat aquesta Mascota de favorits',
                duration: 2000,
                color: 'danger'
            });
            toast.present();
        });
    }
};
CatsPage.ctorParameters = () => [
    { type: src_app_services_rescue_service_service__WEBPACK_IMPORTED_MODULE_2__.RescueServiceService },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: src_app_services_likes_service__WEBPACK_IMPORTED_MODULE_4__.LikesService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController }
];
CatsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-cats',
        template: _home_ioan_Documents_DAW2_Ionic_PetsIonic_node_modules_ngtools_webpack_src_loaders_direct_resource_js_cats_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_cats_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], CatsPage);



/***/ }),

/***/ 6636:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/auth */ 4400);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/fire/auth */ 9095);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/fire/firestore */ 5357);
/* harmony import */ var _firebase_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @firebase/auth */ 6367);





let AuthService = class AuthService {
    constructor(_auth, _firestore) {
        this._auth = _auth;
        this._firestore = _firestore;
        this._usersCollection = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_1__.collection)(this._firestore, "users");
    }
    isSessionStarted() {
        var session = localStorage.getItem("IONIC_NAVIGATION_PROJECT");
        if (session) {
            return JSON.parse(session).logged;
        }
        return false;
    }
    register(email, passwd, name) {
        var credentials = (0,_angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__.createUserWithEmailAndPassword)(this._auth, email, passwd);
        return credentials.then((user) => {
            //LS => logged
            localStorage.setItem("IONIC_NAVIGATION_PROJECT", JSON.stringify({ 'logged': true }));
            //Firestore => user data
            const usr = {
                email: user.user.email,
                name: user.user.displayName ? user.user.displayName : '',
                uuid: user.user.uid
            };
            // Passem l'UUID a una variable i l'afegim al LS
            this.uuidObt = usr.uuid;
            localStorage.setItem("USER_ID", JSON.stringify({ 'uuid': this.uuidObt }));
            console.log(usr);
            (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_1__.addDoc)(this._usersCollection, usr);
            console.log("Correctly registered");
            return true;
        }).finally(() => {
            return false;
        });
    }
    // Retorna l'UUID ja sigui desde LS o no
    getUuuid() {
        var uuidSession = localStorage.getItem("USER_ID");
        if (uuidSession) {
            this.uuidObt = JSON.parse(uuidSession).uuid;
            return this.uuidObt;
        }
        return this.uuidObt;
    }
    login(email, passwd) {
        var credentials = (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signInWithEmailAndPassword)(this._auth, email, passwd);
        return credentials.then((user) => {
            //LS => logged
            // Assignem l'UUID a una variable i l'afegim al LS
            this.uuidObt = user.user.uid;
            localStorage.setItem("USER_ID", JSON.stringify({ 'uuid': this.uuidObt }));
            localStorage.setItem("IONIC_NAVIGATION_PROJECT", JSON.stringify({ 'logged': true }));
            console.log("Correctly logged");
            return true;
        }).finally(() => {
            return false;
        });
    }
    loginWithGoogle() {
        var credentials = (0,_angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__.signInWithPopup)(this._auth, new _angular_fire_auth__WEBPACK_IMPORTED_MODULE_3__.GoogleAuthProvider());
        console.log(credentials);
    }
    // Deslogueig + eliminar UUID del LS
    logout() {
        (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signOut)(this._auth);
        localStorage.setItem("IONIC_NAVIGATION_PROJECT", JSON.stringify({ 'logged': false }));
        localStorage.removeItem("USER_ID");
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__.Auth },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_1__.Firestore }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 9561:
/*!****************************************************!*\
  !*** ./src/app/services/rescue-service.service.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RescueServiceService": () => (/* binding */ RescueServiceService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ 5357);
/* harmony import */ var _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @firebase/firestore */ 8181);
/* harmony import */ var _models_rescued_pets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../models/rescued-pets */ 2631);





let RescueServiceService = class RescueServiceService {
    constructor(fireService) {
        this.fireService = fireService;
        this._petsCollection = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.collection)(this.fireService, "pets");
        this._Rescue = new _models_rescued_pets__WEBPACK_IMPORTED_MODULE_1__.RescuedPets();
        this._dogs = [];
        this._cats = [];
        this.getDataBBDD();
        this.obtenirGats();
        this.obtenirGossos();
    }
    getDataBBDD() {
        (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.collectionData)(this._petsCollection, { idField: 'id' }).subscribe((dbPets) => {
            this._Rescue.setPet = dbPets;
            console.log(this._Rescue.getPet);
        });
    }
    obtenirGossos() {
        (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.collectionData)((0,_firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.query)(this._petsCollection, (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.where)('type', '==', "dog")), { idField: 'id' }).subscribe((dbDogsGet) => {
            this._dogs = dbDogsGet;
        });
    }
    obtenirGats() {
        (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.collectionData)((0,_firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.query)(this._petsCollection, (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.where)('type', '==', "cat")), { idField: 'id' }).subscribe((dbCats) => {
            this._cats = dbCats;
        });
    }
    get getDogs() {
        return this._dogs;
    }
    get getCats() {
        return this._cats;
    }
    get getPets() {
        return this._Rescue.getPet;
    }
    addPet(pets) {
        (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.addDoc)(this._petsCollection, pets);
        this.getDataBBDD();
    }
    updatePet(pet) {
        const petDocument = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.doc)(this.fireService, "pets", pet.id);
        (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.updateDoc)(petDocument, pet);
    }
    deletePet(id) {
        const dishDocument = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.doc)(this.fireService, "pets", id);
        (0,_firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.deleteDoc)(dishDocument);
    }
};
RescueServiceService.ctorParameters = () => [
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.Firestore }
];
RescueServiceService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root'
    })
], RescueServiceService);



/***/ }),

/***/ 5698:
/*!***************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/pets/cats/cats.page.html ***!
  \***************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Gats</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div>\n    <ion-grid>\n      <ion-row *ngFor=\"let cat of getCats; let idx = index\" [ngClass]=\"['ion-wrap ion-justify-content-center']\">\n        <ion-col size-sm=\"12\" size-md=\"6\">\n          <ion-card [ngClass]=\"['ion-margin ion-justify-content-center']\">\n            <ion-header>\n              <img [src]=\"cat.main_image\">\n            </ion-header>\n              <ion-card-content>\n                <a [routerLink]=\"['pet']\" [queryParams]=\"{id: idx}\">\n                  <h1>{{ cat.name }}</h1>\n                </a>\n                <button *ngIf=\"isSessionStarted() && islike(cat.id) == false\" (click)=\"ferLike(cat.id)\">\n                  <ion-icon name=\"heart-sharp\"></ion-icon>\n                </button>\n                <button *ngIf=\"isSessionStarted() && islike(cat.id) == true\" (click)=\"ferDislike(cat.id)\">\n                  <ion-icon [ngClass]=\"['dislike']\" name=\"heart-dislike-sharp\"></ion-icon>\n                </button>\n              </ion-card-content>\n          </ion-card>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    \n  </div>\n</ion-content>\n");

/***/ }),

/***/ 1855:
/*!************************************************!*\
  !*** ./src/app/pages/pets/cats/cats.page.scss ***!
  \************************************************/
/***/ ((module) => {

module.exports = "ion-card > ion-header {\n  object-fit: cover;\n  max-width: 100%;\n}\nion-card > ion-header img {\n  object-fit: cover;\n  width: 100%;\n  height: 250px;\n}\nion-card > ion-header::after {\n  display: none;\n}\nion-card ion-card-content {\n  display: flex;\n  justify-content: space-between;\n}\nion-card ion-card-content a {\n  text-decoration: none;\n}\nion-card ion-card-content a h1 {\n  font-size: 20px;\n  color: #4ed89e;\n}\nion-card ion-card-content button {\n  color: #4ed89e;\n  background-color: #000;\n  border-radius: 5px;\n  width: 30px;\n  height: 30px;\n}\nion-card ion-card-content button > .dislike {\n  color: #cf5f5f;\n}\ndiv.toast-wrapper.toast-button {\n  background-color: #000 !important;\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhdHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0FBQ0o7QUFDSTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7QUFDUjtBQUdBO0VBQ0ksYUFBQTtBQUFKO0FBSUk7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7QUFEUjtBQUdRO0VBQ0kscUJBQUE7QUFEWjtBQUdZO0VBQ0ksZUFBQTtFQUNBLGNBQUE7QUFEaEI7QUFLUTtFQUNJLGNBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFIWjtBQU1RO0VBQ0ksY0FBQTtBQUpaO0FBU0E7RUFDSSxpQ0FBQTtFQUNBLFdBQUE7QUFOSiIsImZpbGUiOiJjYXRzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJkID4gaW9uLWhlYWRlciB7XG4gICAgb2JqZWN0LWZpdDogY292ZXI7XG4gICAgbWF4LXdpZHRoOiAxMDAlO1xuXG4gICAgaW1nIHtcbiAgICAgICAgb2JqZWN0LWZpdDogY292ZXI7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBoZWlnaHQ6IDI1MHB4O1xuICAgIH1cbn1cblxuaW9uLWNhcmQgPiBpb24taGVhZGVyOjphZnRlciB7XG4gICAgZGlzcGxheTogbm9uZTtcbn1cblxuaW9uLWNhcmQge1xuICAgIGlvbi1jYXJkLWNvbnRlbnQge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5cbiAgICAgICAgYSB7XG4gICAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG5cbiAgICAgICAgICAgIGgxIHtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgICAgICAgICAgY29sb3I6ICM0ZWQ4OWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBidXR0b24ge1xuICAgICAgICAgICAgY29sb3I6ICM0ZWQ4OWU7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICAgICAgd2lkdGg6IDMwcHg7XG4gICAgICAgICAgICBoZWlnaHQ6IDMwcHg7XG4gICAgICAgIH1cblxuICAgICAgICBidXR0b24gPiAuZGlzbGlrZSB7XG4gICAgICAgICAgICBjb2xvcjogI2NmNWY1ZjtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuZGl2LnRvYXN0LXdyYXBwZXIudG9hc3QtYnV0dG9uIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwICFpbXBvcnRhbnQ7XG4gICAgY29sb3I6ICNmZmY7XG59Il19 */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_pets_cats_cats_module_ts.js.map