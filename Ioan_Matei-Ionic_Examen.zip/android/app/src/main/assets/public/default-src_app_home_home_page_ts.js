"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_home_home_page_ts"],{

/***/ 7464:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _home_ioan_Documents_DAW2_Ionic_PetsIonic_node_modules_ngtools_webpack_src_loaders_direct_resource_js_home_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./home.page.html */ 2056);
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss */ 968);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _services_rescue_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/rescue-service.service */ 9561);
/* harmony import */ var _assets_data_general_data_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../assets/data/general_data.json */ 9474);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/auth.service */ 6636);







let HomePage = class HomePage {
    constructor(cService, _authService) {
        this.cService = cService;
        this._authService = _authService;
        this.company = _assets_data_general_data_json__WEBPACK_IMPORTED_MODULE_3__.RescueHouse;
    }
    ngOnInit() { }
    get getPets() {
        return this.cService.getPets;
    }
    get getDogs() {
        return this.cService.getDogs;
    }
    get getCats() {
        return this.cService.getCats;
    }
    isSessionStarted() {
        return this._authService.isSessionStarted();
    }
    logout() {
        this._authService.logout();
    }
};
HomePage.ctorParameters = () => [
    { type: _services_rescue_service_service__WEBPACK_IMPORTED_MODULE_2__.RescueServiceService },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService }
];
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-home',
        template: _home_ioan_Documents_DAW2_Ionic_PetsIonic_node_modules_ngtools_webpack_src_loaders_direct_resource_js_home_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomePage);



/***/ }),

/***/ 2631:
/*!****************************************!*\
  !*** ./src/app/models/rescued-pets.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RescuedPets": () => (/* binding */ RescuedPets)
/* harmony export */ });
class RescuedPets {
    constructor() {
        this._pets = [];
    }
    get getPet() {
        return this._pets;
    }
    set setPet(pets) {
        this._pets = pets;
    }
}


/***/ }),

/***/ 6636:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/auth */ 4400);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/fire/auth */ 9095);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/fire/firestore */ 5357);
/* harmony import */ var _firebase_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @firebase/auth */ 6367);





let AuthService = class AuthService {
    constructor(_auth, _firestore) {
        this._auth = _auth;
        this._firestore = _firestore;
        this._usersCollection = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_1__.collection)(this._firestore, "users");
    }
    isSessionStarted() {
        var session = localStorage.getItem("IONIC_NAVIGATION_PROJECT");
        if (session) {
            return JSON.parse(session).logged;
        }
        return false;
    }
    register(email, passwd, name) {
        var credentials = (0,_angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__.createUserWithEmailAndPassword)(this._auth, email, passwd);
        return credentials.then((user) => {
            //LS => logged
            localStorage.setItem("IONIC_NAVIGATION_PROJECT", JSON.stringify({ 'logged': true }));
            //Firestore => user data
            const usr = {
                email: user.user.email,
                name: user.user.displayName ? user.user.displayName : '',
                uuid: user.user.uid
            };
            // Passem l'UUID a una variable i l'afegim al LS
            this.uuidObt = usr.uuid;
            localStorage.setItem("USER_ID", JSON.stringify({ 'uuid': this.uuidObt }));
            console.log(usr);
            (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_1__.addDoc)(this._usersCollection, usr);
            console.log("Correctly registered");
            return true;
        }).finally(() => {
            return false;
        });
    }
    // Retorna l'UUID ja sigui desde LS o no
    getUuuid() {
        var uuidSession = localStorage.getItem("USER_ID");
        if (uuidSession) {
            this.uuidObt = JSON.parse(uuidSession).uuid;
            return this.uuidObt;
        }
        return this.uuidObt;
    }
    login(email, passwd) {
        var credentials = (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signInWithEmailAndPassword)(this._auth, email, passwd);
        return credentials.then((user) => {
            //LS => logged
            // Assignem l'UUID a una variable i l'afegim al LS
            this.uuidObt = user.user.uid;
            localStorage.setItem("USER_ID", JSON.stringify({ 'uuid': this.uuidObt }));
            localStorage.setItem("IONIC_NAVIGATION_PROJECT", JSON.stringify({ 'logged': true }));
            console.log("Correctly logged");
            return true;
        }).finally(() => {
            return false;
        });
    }
    loginWithGoogle() {
        var credentials = (0,_angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__.signInWithPopup)(this._auth, new _angular_fire_auth__WEBPACK_IMPORTED_MODULE_3__.GoogleAuthProvider());
        console.log(credentials);
    }
    // Deslogueig + eliminar UUID del LS
    logout() {
        (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signOut)(this._auth);
        localStorage.setItem("IONIC_NAVIGATION_PROJECT", JSON.stringify({ 'logged': false }));
        localStorage.removeItem("USER_ID");
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__.Auth },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_1__.Firestore }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 9561:
/*!****************************************************!*\
  !*** ./src/app/services/rescue-service.service.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RescueServiceService": () => (/* binding */ RescueServiceService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ 5357);
/* harmony import */ var _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @firebase/firestore */ 8181);
/* harmony import */ var _models_rescued_pets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../models/rescued-pets */ 2631);





let RescueServiceService = class RescueServiceService {
    constructor(fireService) {
        this.fireService = fireService;
        this._petsCollection = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.collection)(this.fireService, "pets");
        this._Rescue = new _models_rescued_pets__WEBPACK_IMPORTED_MODULE_1__.RescuedPets();
        this._dogs = [];
        this._cats = [];
        this.getDataBBDD();
        this.obtenirGats();
        this.obtenirGossos();
    }
    getDataBBDD() {
        (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.collectionData)(this._petsCollection, { idField: 'id' }).subscribe((dbPets) => {
            this._Rescue.setPet = dbPets;
            console.log(this._Rescue.getPet);
        });
    }
    obtenirGossos() {
        (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.collectionData)((0,_firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.query)(this._petsCollection, (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.where)('type', '==', "dog")), { idField: 'id' }).subscribe((dbDogsGet) => {
            this._dogs = dbDogsGet;
        });
    }
    obtenirGats() {
        (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.collectionData)((0,_firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.query)(this._petsCollection, (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.where)('type', '==', "cat")), { idField: 'id' }).subscribe((dbCats) => {
            this._cats = dbCats;
        });
    }
    get getDogs() {
        return this._dogs;
    }
    get getCats() {
        return this._cats;
    }
    get getPets() {
        return this._Rescue.getPet;
    }
    addPet(pets) {
        (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.addDoc)(this._petsCollection, pets);
        this.getDataBBDD();
    }
    updatePet(pet) {
        const petDocument = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.doc)(this.fireService, "pets", pet.id);
        (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.updateDoc)(petDocument, pet);
    }
    deletePet(id) {
        const dishDocument = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.doc)(this.fireService, "pets", id);
        (0,_firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.deleteDoc)(dishDocument);
    }
};
RescueServiceService.ctorParameters = () => [
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.Firestore }
];
RescueServiceService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root'
    })
], RescueServiceService);



/***/ }),

/***/ 2056:
/*!****************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/home/home.page.html ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Inici</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button *ngIf=\"!isSessionStarted()\" [routerLink]=\"['/login']\">\n        <ion-icon name=\"log-in-outline\"></ion-icon>\n      </ion-button>\n      <ion-button *ngIf=\"isSessionStarted()\" (click)=\"logout()\">\n        <ion-icon name=\"log-out-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngFor=\"let info of company\">\n      \n      <h1 [ngClass]=\"['ion-padding-start']\">Historia {{ info.name }}</h1>\n      <p [ngClass]=\"['ion-padding ion-text-justify']\">{{ info.biography }}</p>\n  \n      <ion-grid [ngClass]=\"['flex ion-justify-content-center']\">\n        <img width=\"700\" src=\"{{ info.main_image }}\">\n      </ion-grid>\n      \n      <h1 [ngClass]=\"['ion-padding-start']\">Localització</h1>\n        \n      <iframe [ngClass]=\"['ion-padding-start']\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14296.667620237671!2d0.5795415281034532!3d41.59344145757309!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a72021d046cd1d%3A0x96462cdd6272567a!2sInstitut%20Caparrella!5e0!3m2!1ses-419!2ses!4v1638980471201!5m2!1ses-419!2ses\" style=\"border:0; height: 300px;\" allowfullscreen=\"\" loading=\"lazy\"></iframe>\n\n      <ion-list>\n        <ion-item>\n          <ion-label>- {{ info.street}}</ion-label>\n        </ion-item>\n        <ion-item>\n          <ion-label>{{ info.zone }}</ion-label>\n        </ion-item>\n        <ion-item>\n          <ion-label>{{ info.p_code }}</ion-label>\n        </ion-item>\n      </ion-list>\n\n      <h1 [ngClass]=\"['ion-padding-start']\">Contacte</h1>\n\n      <ion-list>\n        <ion-item>\n          <ion-label>{{ info.cont_email }}</ion-label>\n        </ion-item>\n        <ion-item>\n          <ion-label>{{ info.phone }}</ion-label>\n        </ion-item>\n      </ion-list>\n    </div>\n  \n</ion-content>\n");

/***/ }),

/***/ 968:
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/***/ ((module) => {

module.exports = "ion-content h1 {\n  color: #7e2fbe;\n}\nion-content .flex {\n  display: flex;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UsY0FBQTtBQUFKO0FBR0U7RUFDRSxhQUFBO0FBREoiLCJmaWxlIjoiaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XG4gIGgxIHtcbiAgICBjb2xvcjogIzdlMmZiZTtcbiAgfVxuXG4gIC5mbGV4IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICB9XG59Il19 */";

/***/ }),

/***/ 9474:
/*!***********************************************!*\
  !*** ./src/app/assets/data/general_data.json ***!
  \***********************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"RescueHouse":[{"name":"+Cota","company":"Rescue House","main_image":"https://cdn.livekindly.co/wp-content/uploads/2019/02/livekindly_tinder.jpg","biography":["El nostre propòsit es ajudar-vos a reunir una parella per a la vostra mascota o amic/ga del ànima. Es basa en quedar al punt de recollida i llogar el gat/gos per 1 dia (19.99€) o 2 dies (29.99€). El nostre punt de recollida és el carrer inventat 24."],"zone":"Lleida","street":"Carrer Inventat","cont_email":"+cota@gmail.com","map":"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14296.667620237671!2d0.5795415281034532!3d41.59344145757309!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a72021d046cd1d%3A0x96462cdd6272567a!2sInstitut%20Caparrella!5e0!3m2!1ses-419!2ses!4v1638980471201!5m2!1ses-419!2ses","phone":"973456456","p_code":"25006"}]}');

/***/ })

}]);
//# sourceMappingURL=default-src_app_home_home_page_ts.js.map